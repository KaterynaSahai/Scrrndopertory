import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Random rnd=new Random();
        int a = rnd.nextInt();
        System.out.println(a);
       String s1=a+ " некоторая строка " + rnd.nextBoolean();
        System.out.println(s1);
        float f = rnd.nextFloat();
        System.out.println(f);
        short s= (short) rnd.nextLong();
        System.out.println(s);
        long l= rnd.nextLong();
        System.out.println(l);
        double d = rnd.nextDouble();
        System.out.println(d);
        char c= (char) rnd.nextInt();
        System.out.println(c);
        byte b= (byte) rnd.nextInt();
        System.out.println(b);
        String s2=String.valueOf(rnd.nextFloat());
        System.out.println(s2);

        Scanner sc= new Scanner(System.in);
        System.out.println("Введите Ваше имя ");
        String name=sc.nextLine();
        System.out.println("Введите Ваш возраст ");
        String age=sc.nextLine();
        System.out.println("Введите Ваш вес ");
        String weight=sc.nextLine();
        System.out.println("Уважаемый " +name+" В свои "+age+" лет Вы для нас дороги, как " + weight + " килограмм золота.");













    }
}