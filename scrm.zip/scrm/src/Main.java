import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scr =new Scanner(System.in);
        int a,b,c,m,n,v,x;
        System.out.println("Введите первое число");
       a = scr.nextInt();
        System.out.println("Введите второе число");
       b = scr.nextInt();
       c=a+b;
        System.out.println(c);
        m=a-b;
        System.out.println(m);
        n=a*b;
        System.out.println(n);
        v=a/b;
        System.out.println(v);
        x=a%b;
        System.out.println(x);


    }
}